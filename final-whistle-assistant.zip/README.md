# final-whistle-assistant
Displays additional information when browsing FinalWhistle website.
