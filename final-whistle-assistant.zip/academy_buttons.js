(function() {
    
    const academyButtonsModulePrefix = "academy_buttons"
    
    console.log(`${new Date().toLocaleString()} ${academyButtonsModulePrefix}: academy_buttons.js script loaded...`)
    
    addCSS("div > button.btn-danger { margin-left: 50px !important; }")
})();
